import json
import os

train_dataset_path = "screen_damage/train"
validation_dataset_path = "screen_damage/validation"

# Load the original labels.json
with open(os.path.join(train_dataset_path, "labels.json"), "r") as f:
    labels_json = json.load(f)

# Find the burnout category and change its ID
for category in labels_json["categories"]:
    if category["name"] == "burnout":
        category["id"] = 1  # Assign a new ID to burnout
        break

# Add a background category with ID 0
labels_json["categories"].insert(0, {"id": 0, "name": "background"})

# Update the annotations to reflect the new burnout ID
for annotation in labels_json["annotations"]:
    if annotation["category_id"] == 0:  # Assuming the original burnout ID was 0
        annotation["category_id"] = 1

# Save the modified labels.json
with open(os.path.join(train_dataset_path, "labels.json"), "w") as f:
    json.dump(labels_json, f)

# Do the same for the validation set
with open(os.path.join(validation_dataset_path, "labels.json"), "r") as f:
    labels_json_val = json.load(f)

for category in labels_json_val["categories"]:
    if category["name"] == "burnout":
        category["id"] = 1
        break

labels_json_val["categories"].insert(0, {"id": 0, "name": "background"})

for annotation in labels_json_val["annotations"]:
    if annotation["category_id"] == 0:
        annotation["category_id"] = 1

with open(os.path.join(validation_dataset_path, "labels.json"), "w") as f:
    json.dump(labels_json_val, f)

print("labels.json files updated successfully.")